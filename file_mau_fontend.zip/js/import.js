function test() {
	a='vuduc';b='vi'
	document.write('vuduc','vi\n','a');
}
